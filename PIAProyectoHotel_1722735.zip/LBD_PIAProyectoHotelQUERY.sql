/*PROYECTO FINAL LABORATORIO BASE DE DATOS	HOTEL*/

/*INTEGRANTES DEL EQUIPO
	FELIX DELGADILLO BARRIOS 		1723054
	MAURO DUQUE MONTEMAYOR			1729077
	LUIS GERARDO JUAREZ MELCHOR		1813171
	PABLO RODRIGUEZ REA				1722735
*/

Create database DBHotel

alter database DBHotel set offline
alter database DBHotel set online

Use DBHotel



/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/*************************************************************CREACION DE LAS TABLAS***********************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/

Create Table Departamento(
	idDepartamento int primary key not null,
	nombre varchar(20) not null
)

Create Table Habitacion(
	idHabitacion int primary key not null,
	clase varchar (30) not null,
	piso int not null,
	fotorgrafia image,
	capacidad int,
	costoDiario money not null
)

Create Table Servicio(
	idServicio int primary key not null,
	nombre varchar (30) not null,
	descripcion varchar (100) not null,
	precio money not null
)

Create Table Huesped(
	idHuesped int primary key not null,
	nombre varchar(30) not null,
	apPat varchar(50) not null,
	apMat varchar(50) not null,
	nomComp as nombre + ' ' + apPat + ' ' + apMat,
	fechaNac DateTime not null check ((DateDIFF(YEAR,FechaNac,GETDATE())) > 18),
	genero char not null,
	telefono varchar(30) not null,
	ciudad varchar(30) not null,
	pais varchar(30) not null
)

create Table Empleado(
	idEmpleado int primary key not null,
	nombre varchar(50) not null,
	apPat varchar(30) not null,
	apMat varchar(30) not null,
	nomComp as nombre + ' ' + apPat + ' ' + apMat,
	foto image,
	fechaNac DateTime not null check ((DateDIFF(YEAR,FechaNac,GETDATE())) > 18),
	idDepartamento int not null FOREIGN KEY (idDepartamento) REFERENCES Departamento(idDepartamento) 
)

Create table TotalServicio(
	idTotalServ int primary key not null
)

Create Table ServicioVendido(
	idSerVen int primary key not null,
	fecha datetime not null check (fecha = (GETDATE()-1) or fecha >= (GETDATE()-1)),
	idServicio int not null FOREIGN KEY (idServicio) REFERENCES Servicio(idServicio),
	idTotalServ int not null FOREIGN KEY (idTotalServ) REFERENCES TotalServicio(idTotalServ)
)

create table Usuario(
	idUsuario int primary key not null,
	username varchar(50) not null,
	passwd varchar(30) not null,
	idEmpleado int not null FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado) 
)

Create Table PeriodoReservacion (
	idPerRes int primary key not null
)

Create Table Disponibilidad(
	idDisponibilidad int primary key not null,
	idHabitacion int not null FOREIGN KEY (idHabitacion) REFERENCES Habitacion(idHabitacion),
	fecha DateTime not null check (fecha = (GETDATE()-1) or fecha >= (GETDATE()-1)),
	idPerRes int FOREIGN KEY (idPerRes) REFERENCES PeriodoReservacion(idPerRes)
)

Create Table Nomina(
	idNomina int primary key not null,
	idEmpleado int not null FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado),
	pagoHora float not null CHECK (pagoHora>=80 and pagoHora <=2500),
	horasTrabajadas int not null CHECK (horasTrabajadas > 0 and horasTrabajadas <=100),
	salarioNeto as horasTrabajadas * pagoHora
)


Create Table Reservacion (
	idReservacion int primary key not null,
	idPerRes int not null FOREIGN KEY (idPerRes) REFERENCES PeriodoReservacion(idPerRes),
)

Create Table Venta(
	idVenta int primary key not null,
	idUsuario int not null FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario),
	idHuesped int not null FOREIGN KEY (idHuesped) REFERENCES Huesped(idHuesped),
	idTotalServ int not null FOREIGN KEY (idTotalServ) REFERENCES TotalServicio(idTotalServ),
	idReservacion int not null FOREIGN KEY (idReservacion) REFERENCES Reservacion(idReservacion)
)



/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************INSERTS*****************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/

insert into Departamento(idDepartamento,nombre) values(1,'Alta Direccion')
insert into Departamento(idDepartamento,nombre) values(2,'Ventas')
insert into Departamento(idDepartamento,nombre) values(3,'Direccion')
insert into Departamento(idDepartamento,nombre) values(4,'Gerencia General')
insert into Departamento(idDepartamento,nombre) values(5,'Alimentos y Bebidas')
insert into Departamento(idDepartamento,nombre) values(6,'Mantenimiento')
insert into Departamento(idDepartamento,nombre) values(7,'Encargado de piso')
insert into Departamento(idDepartamento,nombre) values(8,'Amas de llaves')
insert into Departamento(idDepartamento,nombre) values(9,'Telefonos')
insert into Departamento(idDepartamento,nombre) values(10,'Reservas')
insert into Departamento(idDepartamento,nombre) values(11,'Recepcionista')
insert into Departamento(idDepartamento,nombre) values(12,'Botones')
insert into Departamento(idDepartamento,nombre) values(13,'Marketing')
insert into Departamento(idDepartamento,nombre) values(14,'Comercial')
insert into Departamento(idDepartamento,nombre) values(15,'Recursos Humanos')
insert into Departamento(idDepartamento,nombre) values(16,'Financiero')
insert into Departamento(idDepartamento,nombre) values(17,'Limpieza')
insert into Departamento(idDepartamento,nombre) values(18,'Turismo')
insert into Departamento(idDepartamento,nombre) values(19,'Almacen')
insert into Departamento(idDepartamento,nombre) values(20,'Compras')


insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(1,'primera',3,5,5500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(2,'primera',3,5,5500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(3,'primera',3,5,5500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(4,'primera',3,5,5500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(5,'segunda',2,3,3500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(6,'segunda',2,3,3500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(7,'segunda',2,3,3500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(8,'segunda',2,3,3500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(9,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(10,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(11,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(12,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(13,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(14,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(15,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(16,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(17,'tercera',1,2,2500)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(18,'sencilla',1,1,1800)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(19,'sencilla',1,1,1800)
insert into Habitacion(idHabitacion,clase,piso,capacidad,costoDiario) values(20,'sencilla',1,1,1800)



insert into Servicio(idServicio,nombre,descripcion,precio) values(1,'Desayuno','buffet del restaurante desde las 8:00 a.m hasta las 11:00 a.m',250)
insert into Servicio(idServicio,nombre,descripcion,precio) values(2,'Comida','buffet del restaurante desde la 1:00 p.m hasta las 3:30 p.m',300)
insert into Servicio(idServicio,nombre,descripcion,precio) values(3,'Cena','buffet del restaurante desde las 8:00 p.m hasta las 11:00 p.m',350)
insert into Servicio(idServicio,nombre,descripcion,precio) values(4,'Limpieza a la habitaci�n','Servicio de limpieza diaria de la habitaci�n',275)
insert into Servicio(idServicio,nombre,descripcion,precio) values(5,'Desayuno a la habitaci�n','Servicio de desayuno a la habitaci�n no incluye precio de la comida',50)
insert into Servicio(idServicio,nombre,descripcion,precio) values(6,'Comida a la habitaci�n', 'Servicio de comida a la habitaci�n no incluye precio de la comida',75)
insert into Servicio(idServicio,nombre,descripcion,precio) values(7,'Cena a la habitaci�n', 'Servicio de cena a la habitaci�n no incluye precio de la comida incluye vinos y licores ',150)
insert into Servicio(idServicio,nombre,descripcion,precio) values(8,'Reservaciones','Servicio de reservaci�n de habitaci�n hasta 15 d�as antes del hospedaje',999)
insert into Servicio(idServicio,nombre,descripcion,precio) values(9,'Paseos','Paseos guiados por los lugares mas iconicos de la ciudad precio por persona',350)
insert into Servicio(idServicio,nombre,descripcion,precio) values(10,'Vallet Parking','Servicio de vallet parking desde la llegada hasta la salida, recogida y entrega de veh�culo',175)
insert into Servicio(idServicio,nombre,descripcion,precio) values(11,'Computadoras','Renta de computadoras por hora',20)
insert into Servicio(idServicio,nombre,descripcion,precio) values(12,'Toallas','Servicio de renta de toallas se requiere dejar identificaci�n, renta por dia',150)
insert into Servicio(idServicio,nombre,descripcion,precio) values(13,'Cancha de f�tbol','Uso gratuito de cancha de f�tbol',0)
insert into Servicio(idServicio,nombre,descripcion,precio) values(14,'Cancha de tennis','Renta por hora de cancha de tennis',60)
insert into Servicio(idServicio,nombre,descripcion,precio) values(15,'Consultorio','Consultorio para lesiones y enfermedades leves precio por consulta no incluye medicamentos',100)
insert into Servicio(idServicio,nombre,descripcion,precio) values(16,'Sala de negocios','Renta de sala de negocios por hora',250)
insert into Servicio(idServicio,nombre,descripcion,precio) values(17,'Guarder�a','Servicio de guarder�a precio por hora',350)
insert into Servicio(idServicio,nombre,descripcion,precio) values(18,'Renta de pel�culas','Renta de pel�culas a la carta entrega en habitaci�n',120)
insert into Servicio(idServicio,nombre,descripcion,precio) values(19,'Renta de videojuegos','Renta de consola de videojuegos con 3 videojuegos a elegir por 3 horas',299)
insert into Servicio(idServicio,nombre,descripcion,precio) values(20,'Tel�fono','Uso de tel�fono para llamadas ilimitadas nacionales e internacionales',399)





insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(1,'Juan','Perez', 'Garza', '20/06/1999','M', '8119273892', 'Monterrey', 'Mexico')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(2,'Manuel','Perez', 'Gignac', '2/12/1989','M', '81123434567', 'Guadalupe', 'Mexico')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(3,'Jan','Derrick', 'Deschamps', '30/10/1992','F', '8120725028', 'Paris', 'Francia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(4,'Sofia','Elliot', 'Mcphee', '12/06/1979','F', '01499406063', 'Boden', 'Suecia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(5,'Robert','Downey', 'Jr', '2/08/1974','M', '814546454', 'Rakitino', 'Rusia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(6,'Chris','John', 'Hemsworth', '14/11/1980','M', '81203456849', 'Vydel', 'Rusia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(7,'Samuel','L', 'Jackson', '20/06/1988','M', '8120345728', 'Macaira', 'Portugal')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(8,'Chris','Evans', 'Garza', '20/06/1999','M', '8123123457', 'Itacate', 'Mexico')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(9,'Scarlett','Johansson', 'Martinez', '20/06/1999','F', '8119273892', 'Vichten', 'Luxemburgo')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(10,'Gwyneth','Paltrow', 'Stan', '20/06/1999','F', '810985674839', 'Botto', 'Italia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(11,'Idris','Elba', 'Ruffalo', '20/06/1999','M', '81213425674', 'Vergato', 'Italia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(12,'Mark','Perez', 'Hiddleston', '20/06/1999','M', '810987612485', 'Funaki', 'Japon')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(13,'Jon','Favreau', 'Atwell', '20/06/1999','M', '8119434343', 'Garrick', 'Sudafrica')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(14,'Hayley','Bautista', 'Asano', '20/06/1999','F', '8112345532', 'Cupar', 'Escocia')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(15,'Dave','Diesel', 'Gillan', '20/06/1999','M', '8143423412', 'Santa Clara', 'Peru')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(16,'Chadwick','Booseman', 'Cooper', '20/06/1999','M', '81222345321', 'Paja Peluda', 'Panama')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(17,'Bradley','Holland', 'Hookins', '20/06/1999','M', '81192730003', 'Ofonogama', 'Nigeria')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(18,'Elizabeth','Pratt', 'Saldana', '20/06/1999','F', '8119275604', 'La Cruz', 'Uruguay')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(19,'Bradley','Holland', 'Mackie', '20/06/1999','M', '8119243526', 'Los Angeles', 'Estados Unidos')
insert into Huesped(idHuesped,nombre,apPat,apMat,fechaNac,genero,telefono,ciudad,pais)
			values(20,'Zoe','Higgins', 'Hopkins', '20/06/1999','F', '8119009812', 'Roswell', 'Estados Unidos')



insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(1,'Pablo','Delgadillo','Dominguez','3/10/1990',1)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(2,'Leana','Kerley','Dermody','3/12/1980',2)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(3,'Carlos','Chavez','Mendoza','31/03/1990',2)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(4,'David','Guerra','Facio','5/04/1985',2)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(5,'Senaida','Vanwart','Molina','13/05/1940',3)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(6,'Miguel','Lynn','Lambert','23/11/1995',4)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(7,'Arissa','David','Chadwick','31/10/1990',5)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(8,'Franklin','Lawson','Cobb','07/01/1991',6)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(9,'Max','Mullins','Mcgowan','23/04/1980',7)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(10,'Michalina','Carney','Timms','22/02/1996',8)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(11,'Nate','Lennon','May','27/10/1997',9)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(12,'Adyan','Forrest','Campbell','19/10/1997',10)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(13,'Fatima','Forrest','Mendez','19/03/1999',11)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(14,'Olivia','Fastwood','Boyd','30/01/1992',12)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(15,'Elsa','Mcphee','Hussain','25/11/1991',13)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(16,'Leoni','Devlin','Porter','16/11/1976',14)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(17,'Kailan','Miranda','Patridge','13/10/1987',15)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(18,'Federico','Carlson','Pittman','02/04/1995',16)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(19,'Robertson','Mcclure','Carey','13/07/1997',17)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(20,'Mcneill','Delgadillo','Dominguez','06/08/1996',18)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(21,'Keith','Wheeler','Vazquez','09/11/1990',19)
insert into Empleado(idEmpleado,nombre,apPat,apMat,fechaNac,idDepartamento) values(22,'Sacha','Pike','Rhodes','3/11/1970',20)

insert into TotalServicio(idTotalServ) values(1)
insert into TotalServicio(idTotalServ) values(2)
insert into TotalServicio(idTotalServ) values(3)
insert into TotalServicio(idTotalServ) values(4)
insert into TotalServicio(idTotalServ) values(5)
insert into TotalServicio(idTotalServ) values(6)
insert into TotalServicio(idTotalServ) values(7)
insert into TotalServicio(idTotalServ) values(8)
insert into TotalServicio(idTotalServ) values(9)
insert into TotalServicio(idTotalServ) values(10)
insert into TotalServicio(idTotalServ) values(11)
insert into TotalServicio(idTotalServ) values(12)
insert into TotalServicio(idTotalServ) values(13)
insert into TotalServicio(idTotalServ) values(14)
insert into TotalServicio(idTotalServ) values(15)
insert into TotalServicio(idTotalServ) values(16)
insert into TotalServicio(idTotalServ) values(17)
insert into TotalServicio(idTotalServ) values(18)
insert into TotalServicio(idTotalServ) values(19)
insert into TotalServicio(idTotalServ) values(20)


insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(1,'27/10/2018',1,1)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(2,'27/10/2018',2,1)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(3,'27/10/2018',3,1)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(4,'26/11/2018',4,2) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(5,'28/10/2018',5,3)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(6,'26/11/2018',6,3) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(7,'27/10/2018',7,3)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(8,'15/11/2018',8,4) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(9,'30/10/2018',9,4) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(10,'27/10/2018',10,4)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(11,'20/12/2018',11,4) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(12,'29/10/2018',12,5)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(13,'26/11/2018',13,6) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(14,'26/11/2018',14,7) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(15,'06/11/2018',15,8) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(16,'30/10/2018',16,9) /**/
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(17,'01/11/2018',17,10)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(18,'01/11/2018',18,11)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(19,'02/11/2018',19,12)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(20,'02/11/2018',20,13)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(21,'05/11/2018',1,13)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(22,'10/11/2018',2,14)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(23,'18/11/2018',17,15)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(24,'02/11/2018',14,16)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(25,'02/12/2018',11,17)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(26,'06/11/2018',20,18)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(27,'02/11/2018',16,19)
insert into ServicioVendido(idSerVen,fecha,idServicio,idTotalServ) values(28,'02/11/2018',19,20)

insert PeriodoReservacion(idPerRes) values(1)
insert PeriodoReservacion(idPerRes) values(2)
insert PeriodoReservacion(idPerRes) values(3)
insert PeriodoReservacion(idPerRes) values(4)
insert PeriodoReservacion(idPerRes) values(5)
insert PeriodoReservacion(idPerRes) values(6)
insert PeriodoReservacion(idPerRes) values(7)
insert PeriodoReservacion(idPerRes) values(8)
insert PeriodoReservacion(idPerRes) values(9)
insert PeriodoReservacion(idPerRes) values(10)
insert PeriodoReservacion(idPerRes) values(11)
insert PeriodoReservacion(idPerRes) values(12)
insert PeriodoReservacion(idPerRes) values(13)
insert PeriodoReservacion(idPerRes) values(14)
insert PeriodoReservacion(idPerRes) values(15)
insert PeriodoReservacion(idPerRes) values(16)
insert PeriodoReservacion(idPerRes) values(17)
insert PeriodoReservacion(idPerRes) values(18)
insert PeriodoReservacion(idPerRes) values(19)
insert PeriodoReservacion(idPerRes) values(20)

insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(1,1,'27/10/2018',1)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(2,2,'27/10/2018',2)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(3,3,'28/10/2018',3) /**/
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(4,4,'28/10/2018',3)/**/
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(5,5,'29/10/2018',3) /**/
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(6,6,'27/10/2018',3)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(7,7,'28/10/2018',4)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(8,8,'29/10/2018',4)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(9,9,'30/10/2018',4)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(10,10,'31/10/2018',4)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(11,11,'01/11/2018',4)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(12,12,'02/11/2018',5)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(13,13,'03/11/2018',6)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(14,14,'04/11/2018',6)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(15,15,'05/11/2018',7)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(16,16,'06/11/2018',8)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(17,17,'07/11/2018',9)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(18,18,'08/11/2018',10)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(19,19,'09/11/2018',10)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(20,20,'10/11/2018',10)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(21,10,'01/11/2018',12)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(22,11,'02/11/2018',13)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(23,12,'03/11/2018',14)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(24,5,'27/10/2018',15)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(25,6,'28/10/2018',16)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(26,7,'29/10/2018',17)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(27,16,'07/11/2018',18)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(28,17,'08/11/2018',19)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(29,18,'09/11/2018',20)
insert into Disponibilidad(idDisponibilidad,idHabitacion,fecha,idPerRes) values(30,2,'28/10/2018',11)

insert into Usuario(idUsuario,username,passwd,idEmpleado) values(1,'admin','root',1)
insert into Usuario(idUsuario,username,passwd,idEmpleado) values(2,'LeanaVentas','carlos20181',2)
insert into Usuario(idUsuario,username,passwd,idEmpleado) values(3,'CarlosVentas','leana20181',3)
insert into Usuario(idUsuario,username,passwd,idEmpleado) values(4,'DavidVentas','david20181',4)
insert into Usuario(idUsuario,username,passwd,idEmpleado) values(5,'direccion','gerencia20181',5)

insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(1,1,390,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(2,2,100,50)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(3,3,100,52)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(4,4,100,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(5,5,120,54)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(6,6,150,55)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(7,7,160,50)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(8,8,130,48)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(9,9,170,48)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(10,10,210,46)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(11,11,200,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(12,12,200,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(13,13,260,54)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(14,14,200,50)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(15,15,200,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(16,16,200,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(17,17,250,58)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(18,18,230,56)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(19,19,210,52)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(20,20,200,50)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(21,21,140,58)
insert into Nomina(idNomina,idEmpleado,pagoHora,horasTrabajadas) values(22,22,280,60)



insert into Reservacion(idReservacion,idPerRes) values(1,1)
insert into Reservacion(idReservacion,idPerRes) values(2,2)
insert into Reservacion(idReservacion,idPerRes) values(3,3)
insert into Reservacion(idReservacion,idPerRes) values(4,4)
insert into Reservacion(idReservacion,idPerRes) values(5,5)
insert into Reservacion(idReservacion,idPerRes) values(6,6)
insert into Reservacion(idReservacion,idPerRes) values(7,7)
insert into Reservacion(idReservacion,idPerRes) values(8,8)
insert into Reservacion(idReservacion,idPerRes) values(9,9)
insert into Reservacion(idReservacion,idPerRes) values(10,10)
insert into Reservacion(idReservacion,idPerRes) values(11,11)
insert into Reservacion(idReservacion,idPerRes) values(12,12)
insert into Reservacion(idReservacion,idPerRes) values(13,13)
insert into Reservacion(idReservacion,idPerRes) values(14,14)
insert into Reservacion(idReservacion,idPerRes) values(15,15)
insert into Reservacion(idReservacion,idPerRes) values(16,16)
insert into Reservacion(idReservacion,idPerRes) values(17,17)
insert into Reservacion(idReservacion,idPerRes) values(18,18)
insert into Reservacion(idReservacion,idPerRes) values(19,19)
insert into Reservacion(idReservacion,idPerRes) values(20,20)



insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(1,2,1,1,1)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(2,3,2,2,2)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(3,4,3,3,3)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(4,2,4,4,4)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(5,3,5,5,5)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(6,4,6,6,6)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(7,2,7,7,7)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(8,3,8,8,8)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(9,4,9,9,9)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(10,2,10,10,10)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(11,2,11,11,11)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(12,3,12,12,12)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(13,3,13,13,13)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(14,4,14,14,14)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(15,2,15,15,15)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(16,3,16,16,16)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(17,4,17,17,17)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(18,2,18,18,18)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(19,3,19,19,19)
insert into Venta(idVenta,idUsuario,idHuesped,idTotalServ,idReservacion) values(20,4,20,20,20)

select * from Departamento
select * from Habitacion
Select * from Servicio
Select * from Huesped
Select * from Empleado
Select * from TotalServicio
Select * from ServicioVendido
select * from Disponibilidad
select * from Usuario
Select * from PeriodoReservacion
Select * from Nomina
Select * from Reservacion
select * from Venta

/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************SELECTS*****************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/*
20 select b�sicos 
		- cambiar nombre de columnas
		- usar alias
		- usar funciones

16 selects Join
	- que incluya cross, inner, left, right

20 selects con where en diferentes tablas y columnas
	- 1 con order by

20 selects con funciones de agregaci�n (min, max, avg, sta, count) 
	8 sin group by
	12 con group by
		- 1 con having
12 select con join y group by

4 select into con drop table y reinsertar filas
*/

select sum(h.costoDiario) as TotalCostoDiario
from Habitacion as h

select sum(h.capacidad) as TotalCapacidad
from Habitacion as h

select sum(s.precio) as TotalPrecio
from Servicio as s

select sum(n.pagoHora) as TotalPagoHora
from Nomina as n

select sum(n.horasTrabajadas) as TotalHorasTrabajadas
from Nomina as n

select sum(n.salarioNeto) as TotalSalarios
from Nomina as n

select len(d.nombre) as LongitudNombreDpto
from Departamento as d

select len(h.clase) as LongitudClase
from Habitacion as h

select len(s.descripcion) as LongitudDescripcion
from Servicio as s

select len(s.nombre) as LongitudNombreServicio
from Servicio as s

select len(h.telefono) as LongitudTelefono
from Huesped as h

select len(h.nomComp) as LongitudNombre
from Huesped as h

select len(e.nomComp) as LongitudNombreEmpleado
from Empleado as e

select max(h.capacidad) as CapacidadMayor
from Habitacion as h

select max(h.piso) as PisoMayor
from Habitacion as h

select max(h.costoDiario) as CostoDiarioMayor
from Habitacion as h

select max(s.precio) as PrecioMayor
from Servicio as s

select max(n.salarioNeto) as SalarioMayor
from Nomina as n

select min(h.capacidad) as CapacidadMenor
from Habitacion as h

select min(h.piso) as PisoMenor
from Habitacion as h

select min(h.costoDiario) as CostoDiarioMenor
from Habitacion as h

select min(s.precio) as PrecioMenor
from Servicio as s

select min(n.salarioNeto) as SalarioMenor
from Nomina as n

/*4 selects Join
	- que incluya cross, inner, left, right
*/

select e.Nombre, e.apPat, e.apMat,
	n.salarioNeto
from Empleado as e,Nomina as n

select e.idEmpleado, e.nomComp 
as 'Nombre del Empleado', d.nombre as Departamento, n.horasTrabajadas, n.salarioNeto
from  Departamento as d 
cross join Empleado as e right join Nomina as n
on n.idEmpleado = e.idEmpleado AND d.idDepartamento = e.idDepartamento

/*Se muestran las cuentas de los empleados*/
select u.idUsuario, u.username, u.passwd,
	   e.idEmpleado
from Usuario as u
left join Empleado as e
on u.idUsuario = e.idEmpleado


select (e.Nombre + ' ' + e.ApPat+ ' ' +e.ApMat) as NombreCompleto,
	   d.nombre
from Empleado as e
right join Departamento as d on d.idDepartamento = e.idDepartamento
where d.nombre = 'Alimentos y Bebidas'

/*	
	5 selects con where en diferentes tablas y columnas
		- 1 con order by
*/

/*Mostrar las habitaciones con un costo menor a 5000*/
select idHabitacion , costoDiario
from Habitacion 
where costoDiario < 5000

select idServicio , precio
from Servicio
where precio < 300

select idNomina , pagoHora
from Nomina
where pagoHora > 250

select idNomina , salarioNeto
from Nomina
where pagoHora > 5000

select idNomina , horasTrabajadas
from Nomina
where horasTrabajadas > 50


/*Mostrar los servicios solicitados por el cliente Carlos*/
select v.idVenta,
	h.nombre, h.apPat,
	s.*
from Venta as v
inner join Huesped as h on h.idHuesped = v.idHuesped
inner join ServicioVendido as sv on sv.idTotalServ = v.idVenta
inner join Servicio as s on s.idServicio = v.idTotalServ
where h.nombre = 'Carlos'

select (e.Nombre + ' ' + e.ApPat+ ' ' +e.ApMat) as NombreCompleto,
	   d.nombre
from Empleado as e
left join Departamento as d on d.idDepartamento = e.idDepartamento
where d.nombre = 'Direccion'

select (e.Nombre + ' ' + e.ApPat+ ' ' +e.ApMat) as NombreCompleto,
	   d.nombre
from Empleado as e
left join Departamento as d on d.idDepartamento = e.idDepartamento
where d.nombre = 'Ventas'

/*Se muestran las clases de las habitaciones*/
select h.idHabitacion,
	   h.clase
from Venta as v
left join Habitacion as h on h.idHabitacion = h.idHabitacion
where h.clase = 'primera'
order by h.idHabitacion desc




/*
	5 selects con funciones de agregaci�n (min, max, avg, sta, count) 
		- 2 sin group by
		- 3 con group by
			- 1 con having
*/


select min(precio) as 'Servicio menos caro'
from Servicio

select min(costoDiario) as 'Menor costo Diario'
from Habitacion

select min(precio) as 'Menor precio'
from Servicio

select min(salarioNeto) as 'Menor salario Neto'
from Nomina

select min(horasTrabajadas) as 'Menor horasTrabajadas'
from Nomina

select min(pagoHora) as 'Menor pago por hora'
from Nomina

select max(pagoHora) as 'Mayor pago por hora'
from Nomina

select max(horasTrabajadas) as 'Mayor horasTrabajadas'
from Nomina

select max(salarioNeto) as 'Mayor salario Neto'
from Nomina

select max(precio) as 'Mayor precio'
from Servicio

select max(costoDiario) as 'Mayor costo Diario'
from Habitacion

/*Se muestra cu�l es el piso m�s alto del hotel*/
select max(piso) as 'Piso m�s alto'
from Habitacion

/*Muestra el n�mero de empleados que tiene cada departamento*/
select count(e.idempleado) as 'N�mmero de empleados', d.nombre
from Empleado as e
inner join Departamento as d on d.idDepartamento = e.idDepartamento
group by d.nombre

/*Se muestra cu�ntos clientes han pedido un servicio en espec�fico*/
 select count(h.idHuesped) as 'N�mero de clientes', s.nombre
from venta as v
inner join Huesped as h on h.idHuesped = v.idHuesped
inner join ServicioVendido as sv on sv.idServicio = v.idVenta
inner join Servicio as s on s.idServicio = sv.idServicio
group by s.nombre

/*Se muestran los pisos con 3 o m�s habitaciones*/
select count(idHabitacion) as 'Num Habitaciones', piso
from Habitacion
group by piso
having count(idHabitacion) >= 3
order by count(idHabitacion) desc


/*
	3 select con join y group by
*/

/*Mostrar cantidad de empleados por cada departamento*/
select count(e.idempleado) as 'Num Empleados por Dpto', d.nombre
from Empleado as e
inner join Departamento as d on d.idDepartamento = e.idDepartamento
group by d.nombre

/*Muestra la cantidad de clientes por cada venta*/
select count(h.idHuesped) as 'Num clientes', v.idVenta
from Venta as v
inner join Huesped as h on h.idHuesped = v.idHuesped
group by v.idVenta

/*Mostrar cantidad de servicios pedidos*/
select count(h.idHuesped) as 'Cant Servicios', s.nombre
from venta as v
inner join Huesped as h on h.idHuesped = v.idHuesped
inner join ServicioVendido as sv on sv.idTotalServ = v.idVenta
inner join Servicio as s on s.idServicio = sv.idServicio
group by s.nombre

/*1 select into con drop table y reinsertar filas*/
select idEmpleado, nombre, apPat, apMat, nomComp, foto, fechaNac, idDepartamento
into #empleado
from Empleado

drop table Empleado

create table Empleado(
	idEmpleado int NOT NULL,
	nombre varchar(50) NULL,
	apPat varchar(50) NULL,
	apMat varchar(50) NULL,
	nomComp  as (nombre+' '+apPat+' '+apMat),
	foto image NULL,
	fechaNac datetime NOT null, 
	idDepartamento int NULL)

insert into  Empleado(idEmpleado, nombre, apPat, apMat, foto, fechaNac, idDepartamento)
select idEmpleado, nombre, apPat, apMat, idDepartamento
from #empleado  /*TABLA TEMPORAL EMPLEADO*/

select * from Empleado


/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/*************************************************************PROCEDIMIENTOS ALMACENADOS*******************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/*Stored Procedure 1*/
create procedure ConsultaDeNomina(@IdEmpleado int)
as
begin
	select e.idEmpleado, e.nomComp, d.nombre as Departamento, n.pagoHora, n.HorasTrabajadas, n.salarioNeto
	from Nomina as n inner join Empleado as e on e.idEmpleado = n.idEmpleado
	inner join Departamento as d on d.idDepartamento = e.idDepartamento
	where n.idEmpleado = @IdEmpleado
end
exec ConsultaDeNomina 1
exec ConsultaDeNomina 2

/*Stored procedure 2*/
create procedure ConsultaVentasUsuario(@IdUsuario int)
as
begin
	select v.idVenta, v.idUsuario, s.nombre
	from 
	Usuario as u inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	where v.idUsuario = @IdUsuario
end

exec ConsultaVentasUsuario 4

/*StoredProcedure 3*/
create procedure EmpleadosPorDepartamento(@idDepartamento int)
as
begin
	select d.nombre as 'Departamento', e.nomComp as 'NombreEmpleado'
	from Departamento  as d inner join Empleado as e on d.idDepartamento = e.idDepartamento
	where d.idDepartamento = @idDepartamento
end

exec EmpleadosPorDepartamento 2

/*Stored Procedure 4*/
create procedure ConsultaReservacionesPorFecha(@fecha date)
as
begin
	select r.idReservacion, h.nomComp as 'Nombre del Cliente', CAST(d.fecha as varchar(MAX)) as 'FechaReservada'
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
			Where d.fecha = @Fecha
end

exec ConsultaReservacionesPorFecha '26/10/2018'
exec ConsultaReservacionesPorFecha '27/10/2018'

/*Stored Procedure 5*/
create proc ConsultaVentasPorFecha(@fecha date)
as
begin
	select v.idVenta, e.nomComp as 'Vendi�', u.idUsuario, h.nomComp as 'Huesped', s.nombre as 'ServicioComprado', CAST(sv.fecha as varchar(MAX)) as 'FechaCompraServicio'
	from 
	Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
	inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	where sv.fecha = @fecha
end

exec ConsultaVentasPorFecha '26/10/2018'
exec ConsultaVentasPorFecha '27/10/2018'

/*Stored Procedure 6*/
create proc ServicioVendidoEnElDiaPorNombre(@nombreServ varchar(50))
as
begin
	select SUM(s.precio) as 'Total ventas del servicio', s.nombre
		from 
		Usuario as u inner join Venta as v on u.idUsuario = v.idUsuario
		inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
		inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
		inner join Servicio as s on s.idServicio = sv.idServicio
		where s.nombre = @nombreServ
		group by (s.nombre)
end

exec ServicioVendidoEnElDiaPorNombre 'Desayuno'

/*Stored procedure 7*/
create procedure VentaDeReservacionesPorFecha(@fecha date)
as
begin
	select SUM(hab.costoDiario) as 'Ganancias del dia en reservaciones'
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
				inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
			Where d.fecha = @fecha
end

exec VentaDeReservacionesPorFecha '26/10/2018'


/*Stored procedure 8*/
create procedure ServiciosVendidasFiltroMes(@mes int)
as
begin
	select v.idVenta, e.nomComp as 'Vendi�', u.idUsuario, h.nomComp as 'Huesped', s.nombre as 'ServicioComprado', s.precio, CAST(sv.fecha as varchar(MAX)) as 'FechaCompraServicio'
	from 
	Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
	inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	where MONTH(sv.fecha) = @mes
end

exec ServiciosVendidasFiltroMes 10

/*Stored Procedure 9*/
create proc ReservacionesVendidasFiltroMes(@mes int)
as
begin
	select r.idReservacion, d.idHabitacion, hab.costoDiario, h.nomComp as 'Nombre del Cliente', CAST(d.fecha as varchar(MAX)) as 'FechaReservada'
	from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
		inner join Reservacion as r on r.idReservacion = v.idReservacion
		inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
		inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
		inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
	Where MONTH(d.fecha) = @mes
end

exec ReservacionesVendidasFiltroMes 10

/*Stored Procedure 10*/
create proc ReporteVentaServFiltroMes(@mes int)
as
begin
	select SUM(s.precio) as 'Total Corte de Ventas del Mes'
	from 
		Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
		inner join Venta as v on u.idUsuario = v.idUsuario
		inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
		inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
		inner join Servicio as s on s.idServicio = sv.idServicio
		inner join Huesped as h on v.idHuesped = h.idHuesped
	where MONTH(sv.fecha) = @mes
end

exec ReporteVentaServFiltroMes 10

/*Stored Procedure 11*/
create procedure ReporteVentaReservFiltroMes(@mes int)
as
begin
	select SUM(hab.costoDiario) as 'Ganancia del mes en reservaciones' 
	from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
		inner join Reservacion as r on r.idReservacion = v.idReservacion
		inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
		inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
		inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
	Where MONTH(d.fecha) = @mes
end

exec ReporteVentaReservFiltroMes 10

/*Stored Procedure 12*/
create procedure VentasTotalesPorFecha(@fecha date)
as
begin
	select dbo.ReporteTotalDeGananciasPorFecha(@fecha) as 'Ganancias Totales'
end
exec VentasTotalesPorFecha '26/10/2018'

/*Stored Procedure 13*/
create procedure VentasTotalesFiltroMes(@mes int)
as
begin
	select dbo.ReporteMensualTotalDeGananciasFiltroMes(@mes) as 'Ganancias Totales del Mes'
end

exec VentasTotalesFiltroMes 10

/*Stored Procedure 14*/
create procedure CumpleaniosEmpleadoFiltroMes(@mes int)
as
begin
	Select e.nomComp, e.foto, CAST(e.fechaNAC as varchar(MAX)) as 'FechaDeNacimiento'
	from Empleado as e
	where MONTH(e.fechaNac) = @mes
end
exec CumpleaniosEmpleadoFiltroMes 12

/*Stored Procedure 15*/
create procedure HorasTrabajadasPorEmpleado(@idEmpleado int)
as
begin
	Select e.nomComp, n.horasTrabajadas 
	from Nomina as n inner join Empleado as e on n.idEmpleado = e.idEmpleado
	where e.idEmpleado = @idEmpleado
end
exec HorasTrabajadasPorEmpleado 2

/*Stored Procedure 16*/
create procedure ComprobarDisponibHabitacion(@idHab int)
as
begin
	Select h.*, d.fecha as 'fechaReservada' from
	Habitacion as h inner join Disponibilidad as d on h.idHabitacion = d.idDisponibilidad
	where d.fecha = CAST(GETDATE() as DATE) AND h.idHabitacion = @idHab
end

exec ComprobarDisponibHabitacion 2

/*Stored Procedure 17*/
create procedure CantServiciosPedudosPorClienteEspecifico(@nomComp varchar(MAX))
as
begin
	select h.nomComp as 'Huesped', COUNT(s.nombre) as 'Cantidad de Servicios Comprados'
	from
	Venta as v inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	where h.nomComp like '%' + @nomComp + '%'
	group by (h.nomComp)
end

exec CantServiciosPedudosPorClienteEspecifico 'Juan'


/*Stored Procedure 18*/
create procedure CumpleaniosHuespedFiltroMes(@mes int)
as
begin
	Select h.nomComp, CAST(h.fechaNac as varchar(MAX)) as 'Fecha de Nacimiento', hab.idHabitacion, hab.piso
	from Huesped as h inner join Venta as v on v.idHuesped = h.idHuesped
	inner join Reservacion as r on r.idReservacion = v.idReservacion
	inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
	inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
	inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
	where MONTH(h.fechaNac) = @mes
end
exec CumpleaniosHuespedFiltroMes 10

/*Stored Procedure 19*/
create Procedure BuscarVentaPorNoTicket(@idVenta int)
as
begin
	Select v.idVenta, v.idUsuario, e.nomComp as 'Vendedor', h.nomComp as 'Huesped', hab.idHabitacion, s.nombre as 'Servicios Comprados'
	from Venta as v inner join Usuario as u on v.idUsuario = u.idUsuario
	inner join Empleado as e on e.idEmpleado = u.idEmpleado
	inner join Huesped as h on v.idHuesped = h.idHuesped
	inner join TotalServicio as tv on tv.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on sv.idServicio = s.idServicio
	inner join Reservacion as r on r.idReservacion = v.idReservacion
	inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
	inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
	inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
	where v.idVenta = @idVenta
end

exec BuscarVentaPorNoTicket 1

/*StoredProcedure 20*/
create procedure BackupBaseDeDatos
as
declare @path varchar(MAX) = N'c:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Backup\BDHotel.bak'
declare @name varchar(MAX) = N'DBHotel-Completa Base de datos Copia de seguridad'
begin

	BACKUP DATABASE [DBHotel] 
	TO  DISK = @path
	WITH NOFORMAT, NOINIT,  NAME = @name, SKIP, NOREWIND, NOUNLOAD,  STATS = 10
end

exec BackupBaseDeDatos



/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************VISTAS*******************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/

/*Vista 1*/
create view NominasAscendentemente as(
	select e.idEmpleado, e.nomComp, d.nombre as Departamento, n.pagoHora, n.HorasTrabajadas, n.salarioNeto
	from Nomina as n inner join Empleado as e on e.idEmpleado = n.idEmpleado
	inner join Departamento as d on d.idDepartamento = e.idDepartamento
	order by salarioNeto asc
	OFFSET 0 ROWS
)
select * from NominasAscendentemente

/*Vista 2*/
create view VentasMasRecientes15 as(
	select top 15
	 v.idVenta, e.nomComp as 'Vendi�', u.idUsuario, h.nomComp as 'Huesped', s.nombre as 'ServicioComprado', s.precio, CAST(sv.fecha as varchar(MAX)) as 'FechaCompraServicio'
	from 
	Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
	inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	order by(FechaCompraServicio) desc
)
select * from VentasMasRecientes15


/*Vista 3*/
create view CantEmpleadosPorDepartamento as(
	Select Count(g.NombreEmpleado) as 'EmpleadosPorDpto', g.Departamento
	from (select d.nombre as 'Departamento', e.nomComp as 'NombreEmpleado'
		from Departamento  as d inner join Empleado as e on d.idDepartamento = e.idDepartamento) as g
	group by (g.Departamento)
		
)
select * from CantEmpleadosPorDepartamento

/*Vista 4*/
create view ReservacionesDelDia as(
	select r.idReservacion, d.idHabitacion, hab.costoDiario, h.nomComp as 'Nombre del Cliente', CAST(d.fecha as varchar(MAX)) as 'FechaReservada'
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
				inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
			Where d.fecha = CAST(GETDATE() as date)
)


select * from ReservacionesDelDia


/*Vista 5*/
create view VentasDelDia as(
	select v.idVenta, e.nomComp as 'Vendi�', u.idUsuario, h.nomComp as 'Huesped', s.nombre as 'ServicioComprado', s.precio, CAST(sv.fecha as varchar(MAX)) as 'FechaCompraServicio'
	from 
	Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
	inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	where sv.fecha = CAST(GETDATE() as date)
)

select * from VentasDelDia

/*Vista 6*/
create view VentaDeServiciosDelDia as(
	select SUM(s.precio) as 'Total Corte de ventas'
	from 
	Usuario as u inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	where sv.fecha = CAST(GETDATE() as date)
)

select * from VentaDeServiciosDelDia

/*Vista 7*/
create view VentaDeReservacionesDelDia as(
	select SUM(hab.costoDiario) as 'Ganancias del dia en reservaciones'
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
				inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
			Where d.fecha = CAST(GETDATE() as date)
)

select * from VentaDeReservacionesDelDia

/*Vista 8*/
create view ReporteDeVentasMensuales as(
	select v.idVenta, e.nomComp as 'Vendi�', u.idUsuario, h.nomComp as 'Huesped', s.nombre as 'ServicioComprado', s.precio, CAST(sv.fecha as varchar(MAX)) as 'FechaCompraServicio'
	from 
	Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
	inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	where MONTH(sv.fecha) = MONTH(GETDATE())
)
select * from ReporteDeVentasMensuales

/*Vista 9*/
create view ReporteDeReservacionesDelMes as(
	select r.idReservacion, d.idHabitacion, hab.costoDiario, h.nomComp as 'Nombre del Cliente', CAST(d.fecha as varchar(MAX)) as 'FechaReservada'
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
				inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
			Where MONTH(d.fecha) = MONTH(GETDATE())
)
select * from ReporteDeReservacionesDelMes

/*Vista 10*/
create view VentaDeServiciosDelMes as(
	select SUM(s.precio) as 'Total Corte de Ventas del Mes'
	from 
	Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
	inner join Venta as v on u.idUsuario = v.idUsuario
	inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	where MONTH(sv.fecha) = MONTH(GETDATE())
)
select * from VentaDeServiciosDelMes

/*Vista 11*/
create view VentaDeReservacionesDelMes as(
	select SUM(hab.costoDiario) as 'Ganancia del mes en reservaciones' 
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
				inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
			Where MONTH(d.fecha) = MONTH(GETDATE())
)
select * from VentaDeReservacionesDelMes

/*Vista 12*/
create view VentasTotalesDelDia as(
	select dbo.ReporteDiarioTotalDeGanancias() as 'Ganancias Totales'
)
select * from VentasTotalesDelDia

/*Vista 13*/
create view VentasTotalesDelMes as(
	select dbo.ReporteMensualTotalDeGanancias() as 'Ganancias Totales del Mes'
)
select * from VentasTotalesDelMes

/*Vista 14*/
create view CumpleaniosDeEmpleado as(
	Select e.nomComp, e.foto, CAST(e.fechaNAC as varchar(MAX)) as 'FechaDeNacimiento'
	from Empleado as e
	where MONTH(e.fechaNac) = MONTH(GETDATE()) AND DAY(e.fechaNac) = DAY(GETDATE())
)
select * from CumpleaniosDeEmpleado

/*Vista 15*/
create view EmpleadosQueCumplenTodasSusHoras as(
	Select e.nomComp, n.horasTrabajadas 
	from Nomina as n inner join Empleado as e on n.idEmpleado = e.idEmpleado
	where n.horasTrabajadas >= 56
)
select * from EmpleadosQueCumplenTodasSusHoras

/*Vista 16*/
create view HabitacionesDisponibles as(
	Select h.* from
	Habitacion as h inner join Disponibilidad as d on h.idHabitacion = d.idDisponibilidad
	where h.idHabitacion != d.idHabitacion AND d.fecha = CAST(GETDATE() as DATE)
)
Select * from HabitacionesDisponibles

/*Vista 17*/
create view CantidadDeServiciosPedidosPorClientes as(
	select h.nomComp as 'Huesped', COUNT(s.nombre) as 'Cantidad de Servicios Comprados'
	from
	Venta as v inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
	inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
	inner join Servicio as s on s.idServicio = sv.idServicio
	inner join Huesped as h on v.idHuesped = h.idHuesped
	group by (h.nomComp)
)
select * from CantidadDeServiciosPedidosPorClientes

/*Vista 18*/
create view ReporteGralDeHuespedes as(
	Select h.idHuesped, h.nomComp, h.genero, CAST(h.fechaNac as varchar(Max)) as 'FechaDeNac', h.ciudad, h.pais
	from Huesped as h
)
select * from ReporteGralDeHuespedes

/*Vista 19*/
create view CumpleaniosDeHuesped as(
	Select h.nomComp, CAST(h.fechaNac as varchar(MAX)) as 'Fecha de Nacimiento', hab.idHabitacion, hab.piso
	from Huesped as h inner join Venta as v on v.idHuesped = h.idHuesped
	inner join Reservacion as r on r.idReservacion = v.idReservacion
	inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
	inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
	inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
	where MONTH(h.fechaNac) = MONTH(GETDATE()) AND DAY(h.fechaNac) = DAY(GETDATE())
)
select * from CumpleaniosDeHuesped

/*Vista 20*/
create view NominasTotalesAPagar as(
	Select COUNT(n.idNomina) as 'N�minas totales a pagar'
	from Nomina as n
	where n.salarioNeto > 0
)
select * from NominasTotalesAPagar


/*Vista 21*/
create view TotalAPagarEnNominas as(
	Select SUM(n.salarioNeto) as 'Total a Pagar en N�minas'
	from Nomina as n
)
select * from TotalAPagarEnNominas



/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/*********************************************************************FUNCIONES****************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/

/*Funcion 1*/
create function Func_consultaDeNomina(@idEmp int)
returns table
as
return (
	select e.idEmpleado, e.nomComp, d.nombre as Departamento, n.pagoHora, n.HorasTrabajadas, n.salarioNeto
	from Nomina as n inner join Empleado as e on e.idEmpleado = n.idEmpleado
	inner join Departamento as d on d.idDepartamento = e.idDepartamento
	where n.idEmpleado = @IdEmp
)
select * from dbo.Func_consultaDeNomina(2)

/*Funcion 2*/
Create function SueldosTotales()
returns int
as
begin
	declare @SueldoTotal int = (Select SUM(n.salarioNeto) as 'Sueldo Total de Empleados' from Nomina as n)
	return @SueldoTotal
end

select dbo.SueldosTotales() as 'Suma de Sueldos'

/*Funcion 3*/
create function ReporteDiarioTotalDeGanancias()
returns int
as
begin
	declare @VentaDeServiciosDiario int = (Select * from VentaDeServiciosDelDia)
	declare @VentaDeReservacionesDiario int = (Select * from VentaDeReservacionesDelDia)
	return (@VentaDeServiciosDiario + @VentaDeReservacionesDiario)
end

select dbo.ReporteDiarioTotalDeGanancias() as 'Ganancias Totales'

/*Funcion 4*/
create function ReporteMensualTotalDeGanancias()
returns int
as
begin
	declare @VentaDeServiciosMensual int = (Select * from VentaDeServiciosDelMes)
	declare @VentaDeReservacionesMensual int = (Select * from VentaDeReservacionesDelMes)
	return (@VentaDeServiciosMensual + @VentaDeReservacionesMensual)
end

select dbo.ReporteMensualTotalDeGanancias() as 'Ganancias Totales del Mes'

/*Funcion 5*/
create function ReporteTotalDeGananciasPorFecha(@fecha date)
returns int
as
begin
	declare @VentaDeServiciosDiario int = 
	(
		select SUM(s.precio)
		from 
		Usuario as u inner join Venta as v on u.idUsuario = v.idUsuario
		inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
		inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
		inner join Servicio as s on s.idServicio = sv.idServicio
		where sv.fecha = @fecha
	)
	declare @VentaDeReservacionesDiario int = 
	(
		select SUM(hab.costoDiario)
			from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
				inner join Reservacion as r on r.idReservacion = v.idReservacion
				inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
				inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
				inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
			Where d.fecha = @fecha
	)
	return (@VentaDeServiciosDiario + @VentaDeReservacionesDiario)
end

select dbo.ReporteTotalDeGananciasPorFecha('28/10/2018') as 'Ganancias Totales'

/*Funcion 6*/
create function ReporteMensualTotalDeGananciasFiltroMes(@mes int)
returns int
as
begin
	declare @VentaDeServiciosMensual int = 
	(
		select SUM(s.precio)
		from 
			Empleado as e inner join Usuario as u on e.idEmpleado = u.idEmpleado
			inner join Venta as v on u.idUsuario = v.idUsuario
			inner join TotalServicio as ts on ts.idTotalServ = v.idTotalServ
			inner join ServicioVendido as sv on sv.idTotalServ = v.idTotalServ
			inner join Servicio as s on s.idServicio = sv.idServicio
			inner join Huesped as h on v.idHuesped = h.idHuesped
		where MONTH(sv.fecha) = @mes
	)
	declare @VentaDeReservacionesMensual int = 
	(
		select SUM(hab.costoDiario)
		from Huesped as h inner join Venta as v on h.idHuesped = v.idHuesped
			inner join Reservacion as r on r.idReservacion = v.idReservacion
			inner join PeriodoReservacion as pr on pr.idPerRes = r.idPerRes
			inner join Disponibilidad as d on d.idPerRes = pr.idPerRes
			inner join Habitacion as hab on hab.idHabitacion = d.idHabitacion
		Where MONTH(d.fecha) = @mes
	)
	return (@VentaDeServiciosMensual + @VentaDeReservacionesMensual)
end

select dbo.ReporteMensualTotalDeGananciasFiltroMes(9) as 'Ganancias Totales del Mes'


/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/********************************************************************TRIGGERS******************************************************************/
/**********************************************************************************************************************************************/
/**********************************************************************************************************************************************/
/*TABLAS NECESARIAS PARA LOS TRIGGERS DE LOGS*/
Create Table LogHuesped(
idLogHuesped int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Agregar_Huesped
on Huesped
after insert
as
begin
set nocount on;
insert into LogHuesped(Fecha,Descripcion) select GETDATE(), 'Un huesped fue agregado'
from inserted
end

/**************************************  Log para agregar Venta  **************************************/

Create Table LogVenta(
idLogVenta int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Agregar_Venta
on Venta
after insert
as
begin
set nocount on;
insert into LogVenta(Fecha,Descripcion) select GETDATE(),'Una venta fue creada'
from inserted
end

/**************************************  Log para agregar Habitacion  **************************************/

Create Table LogHabitacion(
idLogHabitacion int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Agregar_Habitacion
on Habitacion
after insert
as
begin
set nocount on;
insert into LogHabitacion(Fecha,Descripcion) select GETDATE(),'Una Habitacion fue creada'
from inserted
end

/**************************************  Log para agregar PeriodoReservacion  **************************************/

Create Table LogPerRes(
idLLogPerRes int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Agregar_PerRes
on PeriodoReservacion
after insert
as
begin
set nocount on;
insert into LogPerRes(Fecha,Descripcion) select GETDATE(),'Un Periodo de Reservacion fue creado'
from inserted
end

/**************************************  Log para agregar Reservacion  **************************************/
Create Table LogReservacion(
idLogReservacion int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Agregar_Reservacion
on Reservacion
after insert
as
begin
set nocount on;
insert into LogReservacion(Fecha,Descripcion) select GETDATE(), 'una Reservacion fue agregada'
from inserted
end

/**************************************  Log para agregar Disponibilidad  **************************************/

Create Table LogDisponibilidad(
idLogDisponibilidad int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Agregar_Disponibilidad
on Disponibilidad
after insert
as
begin
set nocount on;
insert into LogDisponibilidad(Fecha,Descripcion) select GETDATE(),'Una Habitacion fue creada'
from inserted
end

/**************************************  Log para editar Huesped  **************************************/
Create Trigger Editar_Huesped
on Huesped
after update
as
begin
set nocount on;
insert into LogHuesped(Fecha,Descripcion) select GETDATE(),'Un huesped fue editado'
from inserted
end

/**************************************  Log para editar Servicio  **************************************/

Create Table LogServicio(
idLogServicio int PRIMARY KEY identity(1,1),
Fecha datetime,
Descripcion varchar(100)
)

Create Trigger Editar_Servicio
on Servicio
after update
as
begin
set nocount on;
insert into LogServicio(Fecha,Descripcion) select GETDATE(),'Un Servicio fue editado'
from inserted
end

/**************************************  Log para Editar Habitacion  **************************************/
Create Trigger Editar_Habitacion
on Habitacion
after update
as
begin
set nocount on;
insert into LogHabitacion(Fecha,Descripcion) select GETDATE(),'Una Habitacion fue editada'
from inserted
end

/**************************************  Log para eliminar Huesped  **************************************/
Create Trigger Eliminar_Huesped
on Huesped
after delete
as
begin
set nocount on;
insert into LogHuesped(Fecha,Descripcion) select GETDATE(),'Un huesped fue eliminado'
from deleted
end

/**************************************  Log para eliminar Servicio  **************************************/
Create Trigger Eliminar_Servicio
on Servicio
after delete
as
begin
set nocount on;
insert into LogServicio(Fecha,Descripcion) select GETDATE(),'Un Servicio fue eliminado'
from deleted
end

/**************************************  Log para eliminar Habitacion  **************************************/
Create Trigger Eliminar_Habitacion
on Habitacion
after delete
as
begin
set nocount on;
insert into LogHabitacion(Fecha,Descripcion) select GETDATE(),'Una Habitacion fue eliminada'
from deleted
end