PIA Laboratorio de Base de Datos
Base de datos del proyecto Hotel

Integrantes del Equipo
Delgadillo Barrios F�lix 	#1723054
Duque Montemayor Mauro 		#1729077
Ju�rez Melchor Luis Gerardo 	#1813171
Rodr�guez Rea Pablo 		#1722735

Profesor, los selects en el script se encuentran comentados debido a que de no estarlo el script no se ejecuta "de un jal�n" marca error precisamente en los selects y preferimos como equipo que el script se pudiera ejecutar as� de primeras, Se cierra el comentario antes de los selects y despu�s de las instrucciones que se agregaron.
Agregamos el query de toda la base de datos por simplicidad en caso de que cualquier cosa que no tenga idea de que quer�amos lograr con un elemento de la base pueda visualizarlo de manera m�s simple.
